James Roach, Will pfledger, scott baker

to compile server:g++ -std=gnu++11 -lpthread -o myFtpServer myFtpServerThreaded.cpp
to compile client:g++ -std=gnu++11 -o myFtp myFtp.cpp
Both follow execution syntax found in project description

WORK BREAKDOWN 
In the spirit of academic honesty my best estimation of the work breakdown 
for this project is as follows 

James Roach 95%
will pfledger 5%
scott baker 0%

Assign points however you see fit. If you want to look into this fun topic 
further here is our github repo https://github.com/jhroach14/ftpProject2


This project was done in its entirety by James Roach and Will pfledger. We 
hereby state that we have not received unauthorized help of any form.